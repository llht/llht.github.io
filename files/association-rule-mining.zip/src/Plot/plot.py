from matplotlib import pyplot as plt

if __name__ == "__main__":
    plt.title('Apriori and FP-Grwoth Mining-Time Comparison (UNIX)')
    # line 1 points 
    x1 = [0.03,0.05,0.07,0.1] 
    y1 = [2.03,0.37,0.11,0.05]
    # plotting the line 1 points  
    plt.plot(x1, y1, label = "Apriori") 
  
    # line 2 points 
    x2 = [0.03,0.05,0.07,0.1] 
    y2 = [0.077,0.046,0.033,0.026]

    # plotting the line 2 points  
    plt.plot(x2, y2, label = "FP-Grwoth")  

    # naming the x axis 
    plt.xlabel('Support') 
    # naming the y axis 
    plt.ylabel('Time Needed (s)') 

    plt.legend()
    plt.show()
