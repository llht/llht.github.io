"""
    Dummy method to calculate frequent items:
    Brute force enumeration
"""
import re
import csv
import sys
import itertools
import time

# item -> showing time duing 9k+ transactions
itemDic = {}
# list of all transactions, each transaction is represented by list of items
transactionList = []


# return a list of items per transaction
def csvLineParser(line):
    items = []
    items = re.split(',|}|{', line)
    # sanitize list
    items.remove(items[0])
    items.remove(items[0])
    items.remove(items[len(items)-1])
    for i in range(len(items)):
        items[i] = items[i].strip()
    return items

# update frequent item sets based on a new transaction 
def updateFrequentSets(transaction):
    for i in range(len(transaction)):
        if transaction[i] in itemDic:
            itemDic[transaction[i]] += 1
        else:
            itemDic[transaction[i]] = 1

if __name__ == "__main__":
    """
        csv part:
        emulate all possible combinations 
        and store them in a formatted table
    """
    csvPath = sys.argv[1]
    dummyStoreResultPath = sys.argv[2]

    csvFile = open(csvPath, 'r')
    resultFile = open(dummyStoreResultPath, 'w')
    # get all the items, sorted by frequency
    maxItems = 0
    for count, line in enumerate(csvFile):
        if count == 0:
            continue
        transaction = csvLineParser(line)
        if len(transaction) > maxItems:
            maxItems = len(transaction)
        transactionList.append(transaction)
        updateFrequentSets(transaction)
    itemDic = sorted(itemDic.items(), key=lambda x: x[1], reverse=True)

    print(maxItems)
    # list of all items
    items = []
    for check in itemDic:
        items.append(check[0])
    # start write to the csv file, every frequent item
    resultWriter = csv.writer(resultFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    # emulate all possible combinations
    # store frequency itemsets in a csv Table, start from itemset of 1 item to that of number of items
    start_time = time.time()
    for n in range(1, maxItems + 1):
        itemsetDic = {}
        for subset in itertools.combinations(items, n):
            # find subset in transactionList
            for transaction in transactionList:
                if set(subset).issubset(set(transaction)):
                    # turn subset into string
                    itemsetStr = ','.join(str(s) for s in subset)
                    if itemsetStr in itemsetDic:
                        itemsetDic[itemsetStr] += 1
                    else:
                        itemsetDic[itemsetStr] = 1

        # wipe off itemset that frequency below 100 and write 
        itemsetDic = sorted(itemsetDic.items(), key=lambda x: x[1], reverse=True)
        for i in itemsetDic:
            i = tuple(reversed(i))
            if i[0] >= 100:
                resultWriter.writerow(i)
        print("LOG: itemsets of " + str(n) + " item(s)" + " finish parsing.")
        print("---- PASS %s seconds ----" % (time.time() - start_time))
        print("Top 5 frequent itemsets:")
        for i in range(5):
            itemsetDic[i] = tuple(reversed(itemsetDic[i]))
            print(itemsetDic[i])
        print("\n")
        
