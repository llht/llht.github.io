import pyfpgrowth
import time
import sys
import re
from optparse import OptionParser

itemDic = {}   # item name to integer map
def dataFromFile(inputFile, fileType):
    itemList = []  # list of item's list, representing by integer
    # tramsform file into list of items, items are represented in integer
    csvFile = open(inputFile, 'r')
    # assgin integers to every unique item, start from 1
    itemInt = 1
    if fileType == 'grocery':
        for count, line in enumerate(csvFile):
            if count == 0:
                continue
            items = []
            items = re.split(',|}|{', line)
            items.remove(items[0])
            items.remove(items[0])
            items.remove(items[len(items)-1])
            for i in range(len(items)):
                items[i] = items[i].strip()
            # add items to dic
            itemInteger = 0
            for i, item in enumerate(items):
                if item in itemDic:
                    itemInteger = itemDic[item]
                else:
                    itemInteger = itemInt
                    itemInt += 1
                    itemDic[item] = itemInteger
                # transform items into integers
                items[i] = itemInteger
            # add the items to itemList
            items.sort()
            itemList.append(items)
    elif fileType == 'unix':
        items = []
        itemInt = 1
        for count, line in enumerate(csvFile):
            if '**SOF**' in line:
                items.clear()
            elif '**EOF**' in line:
                items.sort()
                itemsSet = set(items)
                itemsNew = list(itemsSet)
                itemList.append(itemsNew)        
            else:
                if line:
                    line = line.strip()
                    if line in itemDic:
                        items.append(itemDic[line])
                    else:
                        itemInteger = itemInt
                        itemDic[line] = itemInteger
                        itemInt += 1
                        items.append(itemInteger)
    else:
        print("Wrong file type, check your spell")
        sys.exit()
    # print(itemList)
    return itemList            

def print_patterns(patterns, transactionN):
    print("------------------------ Patterns:")
    for key in patterns:
        for itemInt in key:
            for keyD, value in itemDic.items():
                if value == itemInt:
                    print(keyD,  end =" ")
                    break
        print("{:.3f}".format(patterns[key]/transactionN))

def print_rules(rules):
    print("------------------------ RULES:")
    for key in rules:
        # print the preitems
        print('(', end=' ')
        for itemInt in key:
            # find 
            for keyD, value in itemDic.items():
                if value == itemInt:
                    print(keyD, end =" ")
                    break
        print(')', end=' ')
        # print the positems
        print(' ==>', end=' ')
        for post in rules[key]:
            if type(post) == tuple:
                print('(', end=' ')
                for itemInt in post: 
                    for keyD, value in itemDic.items():
                        if value == itemInt:
                            print(keyD,  end =" ")
                            break
                print(')', end=' ')
            else:
                print("{:.3f}".format(post))

if __name__ == "__main__":
    optparser = OptionParser()
    optparser.add_option('-f', '--inputFile',
                         dest='input',
                         help='filename containing csv',
                         default=None)
    optparser.add_option('-s', '--minSupport',
                         dest='minS',
                         help='minimum support value',
                         default=0.15,
                         type='float')
    optparser.add_option('-c', '--minConfidence',
                         dest='minC',
                         help='minimum confidence value',
                         default=0.6,
                         type='float')
    optparser.add_option('-t', '--type',
                         dest='fileType',
                         help='Type of the file: grocery or unix?',
                         default='grocery',
                         type='str')
    (options, args) = optparser.parse_args()

    initialTime = time.time()

    inFile = None
    if options.input is None:
            inFile = sys.stdin
    elif options.input is not None:
            inFile = dataFromFile(options.input, options.fileType)
    else:
            print('No dataset filename specified, system with exit\n')
            sys.exit('System will exit')

    patterns = pyfpgrowth.find_frequent_patterns(inFile, options.minS*len(inFile))
    patternTime = time.time() - initialTime
    print_patterns(patterns, len(inFile))
    
    rules = pyfpgrowth.generate_association_rules(patterns, options.minC)
    print_rules(rules)

    print("------------------------ Results:")
    print("Number of patterns: " + str(len(patterns)))
    print("Number of rules: " + str(len(rules)))
    print("Time used to find frequent patterns: " + str(patternTime))

"""
    minSupport = options.minS
    minConfidence = options.minC

    items, rules = runApriori(inFile, minSupport, minConfidence)

    printResults(items, rules)
"""
