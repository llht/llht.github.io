#include <stdio.h>      /*��׼�����������*/  
#include <stdlib.h>     /*��׼�����ⶨ��*/  
#include <unistd.h>     /*Unix ��׼��������*/  
#include <sys/types.h>   
#include <sys/stat.h>     
#include <fcntl.h>      /*�ļ����ƶ���*/  
#include <termios.h>    /*PPSIX �ն˿��ƶ���*/  
#include <errno.h>      /*����Ŷ���*/  
#include <string.h>  
#include <time.h>
#include <pthread.h>
#include <sys/inotify.h>

#include "tcpsock.h"
#include "cJSON.h"
#include "cloud.h"

#define MAIN_DBG(fmt, args...)	printf("DEBUG:%s:%d, "fmt, __FUNCTION__, __LINE__, ##args)
#define MAIN_ERR(fmt, args...)	printf("ERR:%s:%d, "fmt, __FUNCTION__, __LINE__, ##args)

#define BUFFER_SIZE 1024
#define JSON_FILE "/home/lht/Documents/data.json" // TODO: ����Ϊjson�ļ��Ĵ洢λ��

#define SERVER_IP	"120.77.58.34"
#define	SERVER_PORT	8600

int is_auth_ok = 0;

void* post_process(void* param)
{
	int ret;
	CON_REQ con_req;
	PACKET packet;
	POST_REQ post_req;
	struct timespec sleep_time;
	long tick = 0;
	int send_flag = 0;
	int sock = *((int*)param);
	
	con_req.msg_type = PACKET_TYPE_CONN_REQ;
	con_req.device_id = "gj1234";											// TODO: �豸��ʶ
	con_req.key = "71eae571996e4bb691881b05e48facdb"; // TODO: ������Կ
	con_req.ver = "V1.0";
	packet = packet_msg(&con_req);
	ret = send_packet(sock, packet, strlen(packet), 0);
	if(ret < 0){
		MAIN_ERR("PACKET_TYPE_CONN_REQ error\n");
	}
	free_packet_msg(packet);

	//10 milli second
	sleep_time.tv_sec = 0;
	sleep_time.tv_nsec = 100000000;

	memset(&post_req, 0, sizeof(post_req));

	// ����һ��inotifyʾ�����ڼ����ļ�״̬
	char eventBuffer[BUFFER_SIZE];
	int notifyFd = inotify_init();
	if(notifyFd < 0) {
		perror("inotify created failed\n");
		exit(1);
	}
 	int watchD = inotify_add_watch(notifyFd, JSON_FILE, IN_CLOSE_WRITE);
	do {
		// BLOCK���ȴ��ļ����޸�
		int length = read(notifyFd, eventBuffer, BUFFER_SIZE);
		if(length < 0) {
			perror("read file event error\n");
			exit(1);
		}

		if (is_auth_ok) {
			// ��json�ļ�
			char *data = (char *)malloc(BUFFER_SIZE);
			int jsonFd = open(JSON_FILE, O_RDONLY);
			if (jsonFd == -1) {
				perror("open .json file failed\n");
				exit(1);
			}
			int readsz = read(jsonFd, data, 1024);
			if (readsz == 0 || readsz == -1) {
				perror("read file failed or file empty\n");
				exit(1);
			}
			printf("------DATA CONTENT START------\n");
			printf("%s", data);
			printf("------DATA CONTENT END------\n");
			// ���ļ�����װ�����ݰ�����
			// ��������Ϊ1��JSON��ʽ1�ַ�����
			post_req.msg_type = PACKET_TYPE_POST_DATA;
			post_req.msg_id++;
			post_req.data_type = 1;
			post_req.data = (char *)malloc(1024);
			strcpy(post_req.data, data);
			post_req.data_len = strlen(post_req.data);
			packet = packet_msg(&post_req);
			if (packet == NULL) {
				MAIN_ERR("packet_msg JSON 1 error\n");
			}
			else {
				MAIN_DBG("POST JSON 1 \n");
				send_flag = 1;
			}
			free(data);
		}
		if (send_flag) {
			ret = send_packet(sock, packet, strlen(packet), 0);
			if (ret < 0) {
				MAIN_ERR("PACKET_TYPE_POST_DATA error\n");
			}
			free_packet_msg(packet);
			send_flag = 0;
		}
	}while(1);    
	
	// ���ļ��Ӽ����б�ɾ�����رռ���ʵ��
	inotify_rm_watch(notifyFd, watchD);
	close(notifyFd);

	return 0;
}

#define	KEEP_ALIVE_MSG		"$#AT#\r"
#define	KEEP_ALIVE_RSP		"$OK##\r"

void* recv_process(void* param)
{
	char msg_buf[128];
	int ret;
	void* msg_unpacket;
	int* msg_type;
	int sock = *((int*)param);

	while(1){
		memset(msg_buf, 0, sizeof(msg_buf));
		ret = receive_packet(sock, msg_buf, sizeof(msg_buf), 0);
		if(ret > 0){
			//hex_dump((const unsigned char*)msg_buf, ret);
			msg_unpacket = unpacket_msg(msg_buf);
			if(msg_unpacket == NULL){
				if(strcmp(msg_buf, KEEP_ALIVE_MSG) == 0){
					MAIN_DBG("recv keep alive\n");
					ret = send_packet(sock, KEEP_ALIVE_RSP, strlen(KEEP_ALIVE_RSP), 0);
					if(ret < 0){
						MAIN_ERR("send keep alive error\n");
					}else{
						MAIN_DBG("send keep alive OK\n");
					}
				}else{
					hex_dump((const unsigned char*)msg_buf, ret);
					MAIN_DBG("not JSON msg or keep alive msg(%s) \n", msg_buf);
				}
			}else{
				MAIN_DBG("recv:\n%s\n", msg_buf);
				msg_type = (int*)msg_unpacket;
				switch(*msg_type){
					case PACKET_TYPE_CONN_RSP:{
						CON_REQ_RSP* con_req_rsp = (CON_REQ_RSP*)msg_unpacket;

						MAIN_DBG("unpacket, msg_type:%d, status:%d\n", con_req_rsp->msg_type, con_req_rsp->status);
						if(con_req_rsp->status == 0){
							MAIN_DBG("server authentication OK\n");
							is_auth_ok = 1;
						}
						break;
					}
					case PACKET_TYPE_POST_RSP:{
						POST_REQ_RSP* post_req_rsp = (POST_REQ_RSP*)msg_unpacket;

						MAIN_DBG("unpacket, msg_type:%d, msg_id:%d status:%d\n", post_req_rsp->msg_type, post_req_rsp->msg_id, post_req_rsp->status);
						if(post_req_rsp->status == 0){
							MAIN_DBG("POST SUCESS\n");
						}
						
						break;
					}
					case PACKET_TYPE_CMD_REQ:{
						CMD_REQ* cmd_rcv = (CMD_REQ*)msg_unpacket;
						int is_cmd_need_rsp = 0;
						PACKET packet;
						CMD_REQ_RSP* cmd_rsp = (CMD_REQ_RSP*)cmd_rcv;	//CMD_REQ struct is same with CMD_REQ_RSP struct

						MAIN_DBG("recv CMD, data type:%d\n", cmd_rcv->data_type);
						switch(cmd_rcv->data_type){
							case CMD_DATA_TYPE_NUM:
								is_cmd_need_rsp = 1;
								MAIN_DBG("unpacket, msg_type:%d, msg_id:%d apitag:%s, data:%d\n", 
										cmd_rcv->msg_type, cmd_rcv->cmd_id, cmd_rcv->api_tag, *((int*)cmd_rcv->data));
	
								break;
							case CMD_DATA_TYPE_DOUBLE:
								is_cmd_need_rsp = 1;
								MAIN_DBG("unpacket, msg_type:%d, msg_id:%d apitag:%s, data:%f\n", 
										cmd_rcv->msg_type, cmd_rcv->cmd_id, cmd_rcv->api_tag, *((double*)cmd_rcv->data));
								break;
							case CMD_DATA_TYPE_STRING:
								is_cmd_need_rsp = 1;
								MAIN_DBG("unpacket, msg_type:%d, msg_id:%d apitag:%s, data:%s\n", 
										cmd_rcv->msg_type, cmd_rcv->cmd_id, cmd_rcv->api_tag, (char*)cmd_rcv->data);
								break;
							case CMD_DATA_TYPE_JSON:
								is_cmd_need_rsp = 1;
								MAIN_DBG("unpacket, msg_type:%d, msg_id:%d apitag:%s, data:%s\n", 
										cmd_rcv->msg_type, cmd_rcv->cmd_id, cmd_rcv->api_tag, (char*)cmd_rcv->data);
								break;
							default:
								MAIN_ERR("data_type(%d) error\n", cmd_rcv->data_type);
						}
						if(is_cmd_need_rsp){
							cmd_rsp->msg_type = PACKET_TYPE_CMD_RSP;
							packet = packet_msg(cmd_rsp);
							cmd_rsp->msg_type = PACKET_TYPE_CMD_REQ;
							if(packet == NULL){
								MAIN_ERR("packet_msg PACKET_TYPE_CMD_RSP error\n");
								break;
							}
							ret = send_packet(sock, packet, strlen(packet), 0);
							if(ret < 0){
								MAIN_ERR("send PACKET_TYPE_CMD_RSP error\n");
							}else{
								MAIN_DBG("cmd rsp:\n%s\n", packet);
							}
							free_packet_msg(packet);
						}
						break;
					}
					default:
						MAIN_ERR("msg_type(%d) error\n", *msg_type);
						break;
				}
				free_unpacket_msg(msg_unpacket);
			}
		}else if(ret == 0){
			break;
		}
	}

	return 0;
}


int main(int argc, char **argv)
{
	int sock;
	pthread_t send_pid;
	pthread_t recv_pid;

	sock = open_client_port(0);
	if(sock == -1){
		MAIN_ERR("open_client_port error\n");
		return 0;
	}

	if(connection_server(sock, SERVER_IP, SERVER_PORT) < 0){
		MAIN_ERR("connection_server error\n");
		return 0;
	}else{
		MAIN_DBG("connect server OK\n");
	}


    pthread_create(&send_pid, NULL, post_process, &sock);
	pthread_create(&recv_pid, NULL, recv_process, &sock);
	
	pthread_join(send_pid, NULL);
	pthread_join(recv_pid, NULL);
	return 0;
}

